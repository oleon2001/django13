--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-1.pgdg20.04+1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: skyguard; Type: DATABASE; Schema: -; Owner: django13
--

CREATE DATABASE skyguard WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE skyguard OWNER TO django13;

\connect skyguard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: skyguard; Type: DATABASE PROPERTIES; Schema: -; Owner: django13
--

ALTER DATABASE skyguard SET search_path TO '$user', 'public', 'topology';


\connect skyguard

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: gist_geometry_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY public.gist_geometry_ops USING gist;
ALTER OPERATOR FAMILY public.gist_geometry_ops USING gist ADD
    OPERATOR 1 public.<<(public.geometry,public.geometry) ,
    OPERATOR 2 public.&<(public.geometry,public.geometry) ,
    OPERATOR 3 public.&&(public.geometry,public.geometry) ,
    OPERATOR 4 public.&>(public.geometry,public.geometry) ,
    OPERATOR 5 public.>>(public.geometry,public.geometry) ,
    OPERATOR 6 public.~=(public.geometry,public.geometry) ,
    OPERATOR 7 public.~(public.geometry,public.geometry) ,
    OPERATOR 8 public.@(public.geometry,public.geometry) ,
    OPERATOR 9 public.&<|(public.geometry,public.geometry) ,
    OPERATOR 10 public.<<|(public.geometry,public.geometry) ,
    OPERATOR 11 public.|>>(public.geometry,public.geometry) ,
    OPERATOR 12 public.|&>(public.geometry,public.geometry) ,
    OPERATOR 13 public.<->(public.geometry,public.geometry) FOR ORDER BY pg_catalog.float_ops ,
    OPERATOR 14 public.<#>(public.geometry,public.geometry) FOR ORDER BY pg_catalog.float_ops ,
    FUNCTION 3 (public.geometry, public.geometry) public.geometry_gist_compress_2d(internal) ,
    FUNCTION 4 (public.geometry, public.geometry) public.geometry_gist_decompress_2d(internal) ,
    FUNCTION 8 (public.geometry, public.geometry) public.geometry_gist_distance_2d(internal,public.geometry,integer);


ALTER OPERATOR FAMILY public.gist_geometry_ops USING gist OWNER TO postgres;

--
-- Name: gist_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: postgres
--

CREATE OPERATOR CLASS public.gist_geometry_ops
    FOR TYPE public.geometry USING gist FAMILY public.gist_geometry_ops AS
    STORAGE public.box2df ,
    FUNCTION 1 (public.geometry, public.geometry) public.geometry_gist_consistent_2d(internal,public.geometry,integer) ,
    FUNCTION 2 (public.geometry, public.geometry) public.geometry_gist_union_2d(bytea,internal) ,
    FUNCTION 5 (public.geometry, public.geometry) public.geometry_gist_penalty_2d(internal,internal,internal) ,
    FUNCTION 6 (public.geometry, public.geometry) public.geometry_gist_picksplit_2d(internal,internal) ,
    FUNCTION 7 (public.geometry, public.geometry) public.geometry_gist_same_2d(public.geometry,public.geometry,internal);


ALTER OPERATOR CLASS public.gist_geometry_ops USING gist OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO django13;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO django13;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO django13;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO django13;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_message; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.auth_message OWNER TO django13;

--
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_message_id_seq OWNER TO django13;

--
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_message_id_seq OWNED BY public.auth_message.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO django13;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO django13;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(275) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO django13;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO django13;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO django13;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO django13;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO django13;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO django13;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO django13;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO django13;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO django13;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO django13;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO django13;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO django13;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO django13;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: gprs_packet; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.gprs_packet (
    id integer NOT NULL,
    session_id integer NOT NULL,
    request text NOT NULL,
    response text NOT NULL
);


ALTER TABLE public.gprs_packet OWNER TO django13;

--
-- Name: gprs_packet_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.gprs_packet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gprs_packet_id_seq OWNER TO django13;

--
-- Name: gprs_packet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.gprs_packet_id_seq OWNED BY public.gprs_packet.id;


--
-- Name: gprs_record; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.gprs_record (
    id integer NOT NULL,
    packet_id integer NOT NULL,
    idbyte smallint NOT NULL,
    data text NOT NULL
);


ALTER TABLE public.gprs_record OWNER TO django13;

--
-- Name: gprs_record_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.gprs_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gprs_record_id_seq OWNER TO django13;

--
-- Name: gprs_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.gprs_record_id_seq OWNED BY public.gprs_record.id;


--
-- Name: gprs_session; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.gprs_session (
    id integer NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone NOT NULL,
    ip inet NOT NULL,
    port integer NOT NULL,
    dev_id bigint NOT NULL,
    bytes integer NOT NULL,
    packets integer NOT NULL,
    records integer NOT NULL,
    events integer NOT NULL,
    CONSTRAINT gprs_session_bytes_check CHECK ((bytes >= 0)),
    CONSTRAINT gprs_session_events_check CHECK ((events >= 0)),
    CONSTRAINT gprs_session_packets_check CHECK ((packets >= 0)),
    CONSTRAINT gprs_session_records_check CHECK ((records >= 0))
);


ALTER TABLE public.gprs_session OWNER TO django13;

--
-- Name: gprs_session_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.gprs_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gprs_session_id_seq OWNER TO django13;

--
-- Name: gprs_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.gprs_session_id_seq OWNED BY public.gprs_session.id;


--
-- Name: tracker_accellog; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_accellog (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    date timestamp with time zone NOT NULL,
    duration numeric(6,4) NOT NULL,
    "errDuration" numeric(6,4) NOT NULL,
    entry numeric(6,4) NOT NULL,
    "errEntry" numeric(6,4) NOT NULL,
    peak numeric(6,4) NOT NULL,
    "errExit" numeric(6,4) NOT NULL,
    exit numeric(6,4) NOT NULL,
    "position" public.geometry(Point,4326) NOT NULL
);


ALTER TABLE public.tracker_accellog OWNER TO django13;

--
-- Name: tracker_accellog_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_accellog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_accellog_id_seq OWNER TO django13;

--
-- Name: tracker_accellog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_accellog_id_seq OWNED BY public.tracker_accellog.id;


--
-- Name: tracker_addresscache; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_addresscache (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    text text NOT NULL,
    "position" public.geometry(Point,4326)
);


ALTER TABLE public.tracker_addresscache OWNER TO django13;

--
-- Name: tracker_addresscache_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_addresscache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_addresscache_id_seq OWNER TO django13;

--
-- Name: tracker_addresscache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_addresscache_id_seq OWNED BY public.tracker_addresscache.id;


--
-- Name: tracker_alarmlog; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_alarmlog (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    sensor character varying(32) NOT NULL,
    date timestamp with time zone NOT NULL,
    cksum integer NOT NULL,
    duration integer NOT NULL,
    comment character varying(24) NOT NULL
);


ALTER TABLE public.tracker_alarmlog OWNER TO django13;

--
-- Name: tracker_alarmlog_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_alarmlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_alarmlog_id_seq OWNER TO django13;

--
-- Name: tracker_alarmlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_alarmlog_id_seq OWNED BY public.tracker_alarmlog.id;


--
-- Name: tracker_device; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_device (
    imei bigint NOT NULL,
    name character varying(20) NOT NULL,
    speed smallint NOT NULL,
    course smallint NOT NULL,
    date timestamp with time zone,
    "lastLog" timestamp with time zone,
    owner_id integer,
    icon character varying(64) NOT NULL,
    type character varying(64) NOT NULL,
    odom integer,
    altitude integer,
    "position" public.geometry(Point,4326)
);


ALTER TABLE public.tracker_device OWNER TO django13;

--
-- Name: tracker_driver; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_driver (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    middle character varying(40) NOT NULL,
    last character varying(40) NOT NULL,
    birth date NOT NULL,
    cstatus character varying(40) NOT NULL,
    address text NOT NULL,
    phone character varying(40) NOT NULL,
    payroll character varying(40),
    socials character varying(40),
    taxid character varying(40),
    phone1 character varying(40),
    phone2 character varying(40),
    active boolean NOT NULL,
    license character varying(40),
    lic_exp date
);


ALTER TABLE public.tracker_driver OWNER TO django13;

--
-- Name: tracker_driver_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_driver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_driver_id_seq OWNER TO django13;

--
-- Name: tracker_driver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_driver_id_seq OWNED BY public.tracker_driver.id;


--
-- Name: tracker_event; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_event (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    type character varying(16) NOT NULL,
    speed smallint NOT NULL,
    course smallint NOT NULL,
    date timestamp with time zone NOT NULL,
    odom integer,
    altitude integer,
    "position" public.geometry(Point,4326)
);


ALTER TABLE public.tracker_event OWNER TO django13;

--
-- Name: tracker_event_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_event_id_seq OWNER TO django13;

--
-- Name: tracker_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_event_id_seq OWNED BY public.tracker_event.id;


--
-- Name: tracker_geofence; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_geofence (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    owner_id integer NOT NULL,
    base integer,
    fence public.geometry(Polygon,4326) NOT NULL
);


ALTER TABLE public.tracker_geofence OWNER TO django13;

--
-- Name: tracker_geofence_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_geofence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_geofence_id_seq OWNER TO django13;

--
-- Name: tracker_geofence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_geofence_id_seq OWNED BY public.tracker_geofence.id;


--
-- Name: tracker_gsmevent; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_gsmevent (
    event_ptr_id integer NOT NULL,
    source character varying(20) NOT NULL,
    text character varying(180) NOT NULL
);


ALTER TABLE public.tracker_gsmevent OWNER TO django13;

--
-- Name: tracker_ioevent; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_ioevent (
    event_ptr_id integer NOT NULL,
    inputs integer NOT NULL,
    outputs integer NOT NULL,
    indelta integer NOT NULL,
    outdelta integer NOT NULL,
    alarmdelta integer NOT NULL,
    changes text NOT NULL
);


ALTER TABLE public.tracker_ioevent OWNER TO django13;

--
-- Name: tracker_overlays; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_overlays (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    owner_id integer NOT NULL,
    base integer,
    geometry public.geometry(LineString,4326) NOT NULL
);


ALTER TABLE public.tracker_overlays OWNER TO django13;

--
-- Name: tracker_overlays_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_overlays_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_overlays_id_seq OWNER TO django13;

--
-- Name: tracker_overlays_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_overlays_id_seq OWNED BY public.tracker_overlays.id;


--
-- Name: tracker_psical; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_psical (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    sensor character varying(32) NOT NULL,
    offpsi1 numeric(10,6) NOT NULL,
    offpsi2 numeric(10,6) NOT NULL,
    mulpsi1 numeric(10,6) NOT NULL,
    mulpsi2 numeric(10,6) NOT NULL,
    name character varying(32) NOT NULL
);


ALTER TABLE public.tracker_psical OWNER TO django13;

--
-- Name: tracker_psical_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_psical_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_psical_id_seq OWNER TO django13;

--
-- Name: tracker_psical_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_psical_id_seq OWNED BY public.tracker_psical.id;


--
-- Name: tracker_psiweightlog; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_psiweightlog (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    sensor character varying(32) NOT NULL,
    date timestamp with time zone NOT NULL,
    psi1 numeric(20,6) NOT NULL,
    psi2 numeric(20,6) NOT NULL
);


ALTER TABLE public.tracker_psiweightlog OWNER TO django13;

--
-- Name: tracker_psiweightlog_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_psiweightlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_psiweightlog_id_seq OWNER TO django13;

--
-- Name: tracker_psiweightlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_psiweightlog_id_seq OWNED BY public.tracker_psiweightlog.id;


--
-- Name: tracker_resetevent; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_resetevent (
    event_ptr_id integer NOT NULL,
    reason character varying(180) NOT NULL
);


ALTER TABLE public.tracker_resetevent OWNER TO django13;

--
-- Name: tracker_serversms; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_serversms (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    msg character varying(160) NOT NULL,
    sent timestamp with time zone,
    command integer,
    direction integer,
    status integer,
    issued timestamp with time zone
);


ALTER TABLE public.tracker_serversms OWNER TO django13;

--
-- Name: tracker_serversms_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_serversms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_serversms_id_seq OWNER TO django13;

--
-- Name: tracker_serversms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_serversms_id_seq OWNED BY public.tracker_serversms.id;


--
-- Name: tracker_sgavl; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_sgavl (
    device_ptr_id bigint NOT NULL,
    serial integer NOT NULL,
    model smallint NOT NULL,
    swversion character varying(4) NOT NULL,
    inputs integer NOT NULL,
    outputs integer NOT NULL,
    "alarmMask" integer NOT NULL,
    alarms integer NOT NULL,
    "fwFile" character varying(16) NOT NULL,
    "newOutputs" integer,
    "newInflags" character varying(32) NOT NULL,
    "lastFwUpdate" timestamp with time zone,
    harness_id integer NOT NULL,
    comments text,
    sim_id bigint,
    ruta integer,
    economico integer
);


ALTER TABLE public.tracker_sgavl OWNER TO django13;

--
-- Name: tracker_sgharness; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_sgharness (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    in00 character varying(32) NOT NULL,
    in01 character varying(32) NOT NULL,
    in02 character varying(32) NOT NULL,
    in03 character varying(32) NOT NULL,
    in04 character varying(32) NOT NULL,
    in05 character varying(32) NOT NULL,
    in06 character varying(32) NOT NULL,
    in07 character varying(32) NOT NULL,
    in08 character varying(32) NOT NULL,
    in09 character varying(32) NOT NULL,
    in10 character varying(32) NOT NULL,
    in11 character varying(32) NOT NULL,
    in12 character varying(32) NOT NULL,
    in13 character varying(32) NOT NULL,
    in14 character varying(32) NOT NULL,
    in15 character varying(32) NOT NULL,
    out00 character varying(32) NOT NULL,
    out01 character varying(32) NOT NULL,
    out02 character varying(32) NOT NULL,
    out03 character varying(32) NOT NULL,
    out04 character varying(32) NOT NULL,
    out05 character varying(32) NOT NULL,
    out06 character varying(32) NOT NULL,
    out07 character varying(32) NOT NULL,
    out08 character varying(32) NOT NULL,
    out09 character varying(32) NOT NULL,
    out10 character varying(32) NOT NULL,
    out11 character varying(32) NOT NULL,
    out12 character varying(32) NOT NULL,
    out13 character varying(32) NOT NULL,
    out14 character varying(32) NOT NULL,
    out15 character varying(32) NOT NULL,
    "inputCfg" character varying(32) NOT NULL
);


ALTER TABLE public.tracker_sgharness OWNER TO django13;

--
-- Name: tracker_sgharness_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_sgharness_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_sgharness_id_seq OWNER TO django13;

--
-- Name: tracker_sgharness_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_sgharness_id_seq OWNED BY public.tracker_sgharness.id;


--
-- Name: tracker_simcard; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_simcard (
    iccid bigint NOT NULL,
    imsi bigint,
    provider smallint NOT NULL,
    phone character varying(16) NOT NULL
);


ALTER TABLE public.tracker_simcard OWNER TO django13;

--
-- Name: tracker_stats; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_stats (
    id integer NOT NULL,
    name character varying(20) NOT NULL,
    ruta integer NOT NULL,
    economico integer NOT NULL,
    date_start timestamp with time zone,
    date_end timestamp with time zone NOT NULL,
    latitud integer,
    longitud integer,
    distancia integer,
    sub_del integer,
    baj_del integer,
    sub_tra integer,
    baj_tra integer,
    speed_avg integer
);


ALTER TABLE public.tracker_stats OWNER TO django13;

--
-- Name: tracker_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_stats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_stats_id_seq OWNER TO django13;

--
-- Name: tracker_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_stats_id_seq OWNED BY public.tracker_stats.id;


--
-- Name: tracker_ticketdetails; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_ticketdetails (
    id integer NOT NULL,
    imei_id bigint NOT NULL,
    date timestamp with time zone,
    chofer character varying(80) NOT NULL,
    total integer NOT NULL,
    recibido integer NOT NULL,
    ticket text NOT NULL
);


ALTER TABLE public.tracker_ticketdetails OWNER TO django13;

--
-- Name: tracker_ticketdetails_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_ticketdetails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_ticketdetails_id_seq OWNER TO django13;

--
-- Name: tracker_ticketdetails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_ticketdetails_id_seq OWNED BY public.tracker_ticketdetails.id;


--
-- Name: tracker_ticketslog; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_ticketslog (
    id integer NOT NULL,
    data text NOT NULL,
    ruta integer,
    date timestamp with time zone
);


ALTER TABLE public.tracker_ticketslog OWNER TO django13;

--
-- Name: tracker_ticketslog_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_ticketslog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_ticketslog_id_seq OWNER TO django13;

--
-- Name: tracker_ticketslog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_ticketslog_id_seq OWNED BY public.tracker_ticketslog.id;


--
-- Name: tracker_timesheetcapture; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_timesheetcapture (
    id integer NOT NULL,
    name character varying(20) NOT NULL,
    date timestamp with time zone,
    chofer character varying(80) NOT NULL,
    vueltas integer NOT NULL,
    times text NOT NULL
);


ALTER TABLE public.tracker_timesheetcapture OWNER TO django13;

--
-- Name: tracker_timesheetcapture_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_timesheetcapture_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_timesheetcapture_id_seq OWNER TO django13;

--
-- Name: tracker_timesheetcapture_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_timesheetcapture_id_seq OWNED BY public.tracker_timesheetcapture.id;


--
-- Name: tracker_tracking; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_tracking (
    id integer NOT NULL,
    tracking character varying(40) NOT NULL,
    imei_id bigint NOT NULL,
    "stopFence_id" integer NOT NULL,
    start timestamp with time zone NOT NULL,
    stop timestamp with time zone
);


ALTER TABLE public.tracker_tracking OWNER TO django13;

--
-- Name: tracker_tracking_fences; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.tracker_tracking_fences (
    id integer NOT NULL,
    tracking_id integer NOT NULL,
    geofence_id integer NOT NULL
);


ALTER TABLE public.tracker_tracking_fences OWNER TO django13;

--
-- Name: tracker_tracking_fences_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_tracking_fences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_tracking_fences_id_seq OWNER TO django13;

--
-- Name: tracker_tracking_fences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_tracking_fences_id_seq OWNED BY public.tracker_tracking_fences.id;


--
-- Name: tracker_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.tracker_tracking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tracker_tracking_id_seq OWNER TO django13;

--
-- Name: tracker_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.tracker_tracking_id_seq OWNED BY public.tracker_tracking.id;


--
-- Name: udp_udpsession; Type: TABLE; Schema: public; Owner: django13
--

CREATE TABLE public.udp_udpsession (
    session integer NOT NULL,
    imei_id bigint NOT NULL,
    expires timestamp with time zone NOT NULL,
    host character varying(128) NOT NULL,
    port integer NOT NULL,
    "lastRec" integer NOT NULL
);


ALTER TABLE public.udp_udpsession OWNER TO django13;

--
-- Name: udp_udpsession_session_seq; Type: SEQUENCE; Schema: public; Owner: django13
--

CREATE SEQUENCE public.udp_udpsession_session_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.udp_udpsession_session_seq OWNER TO django13;

--
-- Name: udp_udpsession_session_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: django13
--

ALTER SEQUENCE public.udp_udpsession_session_seq OWNED BY public.udp_udpsession.session;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_message id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_message ALTER COLUMN id SET DEFAULT nextval('public.auth_message_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: gprs_packet id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_packet ALTER COLUMN id SET DEFAULT nextval('public.gprs_packet_id_seq'::regclass);


--
-- Name: gprs_record id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_record ALTER COLUMN id SET DEFAULT nextval('public.gprs_record_id_seq'::regclass);


--
-- Name: gprs_session id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_session ALTER COLUMN id SET DEFAULT nextval('public.gprs_session_id_seq'::regclass);


--
-- Name: tracker_accellog id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_accellog ALTER COLUMN id SET DEFAULT nextval('public.tracker_accellog_id_seq'::regclass);


--
-- Name: tracker_addresscache id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_addresscache ALTER COLUMN id SET DEFAULT nextval('public.tracker_addresscache_id_seq'::regclass);


--
-- Name: tracker_alarmlog id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_alarmlog ALTER COLUMN id SET DEFAULT nextval('public.tracker_alarmlog_id_seq'::regclass);


--
-- Name: tracker_driver id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_driver ALTER COLUMN id SET DEFAULT nextval('public.tracker_driver_id_seq'::regclass);


--
-- Name: tracker_event id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_event ALTER COLUMN id SET DEFAULT nextval('public.tracker_event_id_seq'::regclass);


--
-- Name: tracker_geofence id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_geofence ALTER COLUMN id SET DEFAULT nextval('public.tracker_geofence_id_seq'::regclass);


--
-- Name: tracker_overlays id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_overlays ALTER COLUMN id SET DEFAULT nextval('public.tracker_overlays_id_seq'::regclass);


--
-- Name: tracker_psical id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_psical ALTER COLUMN id SET DEFAULT nextval('public.tracker_psical_id_seq'::regclass);


--
-- Name: tracker_psiweightlog id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_psiweightlog ALTER COLUMN id SET DEFAULT nextval('public.tracker_psiweightlog_id_seq'::regclass);


--
-- Name: tracker_serversms id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_serversms ALTER COLUMN id SET DEFAULT nextval('public.tracker_serversms_id_seq'::regclass);


--
-- Name: tracker_sgharness id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgharness ALTER COLUMN id SET DEFAULT nextval('public.tracker_sgharness_id_seq'::regclass);


--
-- Name: tracker_stats id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_stats ALTER COLUMN id SET DEFAULT nextval('public.tracker_stats_id_seq'::regclass);


--
-- Name: tracker_ticketdetails id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ticketdetails ALTER COLUMN id SET DEFAULT nextval('public.tracker_ticketdetails_id_seq'::regclass);


--
-- Name: tracker_ticketslog id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ticketslog ALTER COLUMN id SET DEFAULT nextval('public.tracker_ticketslog_id_seq'::regclass);


--
-- Name: tracker_timesheetcapture id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_timesheetcapture ALTER COLUMN id SET DEFAULT nextval('public.tracker_timesheetcapture_id_seq'::regclass);


--
-- Name: tracker_tracking id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking ALTER COLUMN id SET DEFAULT nextval('public.tracker_tracking_id_seq'::regclass);


--
-- Name: tracker_tracking_fences id; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking_fences ALTER COLUMN id SET DEFAULT nextval('public.tracker_tracking_fences_id_seq'::regclass);


--
-- Name: udp_udpsession session; Type: DEFAULT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.udp_udpsession ALTER COLUMN session SET DEFAULT nextval('public.udp_udpsession_session_seq'::regclass);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_message auth_message_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: gprs_packet gprs_packet_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_packet
    ADD CONSTRAINT gprs_packet_pkey PRIMARY KEY (id);


--
-- Name: gprs_record gprs_record_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_record
    ADD CONSTRAINT gprs_record_pkey PRIMARY KEY (id);


--
-- Name: gprs_session gprs_session_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_session
    ADD CONSTRAINT gprs_session_pkey PRIMARY KEY (id);


--
-- Name: tracker_accellog tracker_accellog_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_accellog
    ADD CONSTRAINT tracker_accellog_pkey PRIMARY KEY (id);


--
-- Name: tracker_addresscache tracker_addresscache_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_addresscache
    ADD CONSTRAINT tracker_addresscache_pkey PRIMARY KEY (id);


--
-- Name: tracker_alarmlog tracker_alarmlog_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_alarmlog
    ADD CONSTRAINT tracker_alarmlog_pkey PRIMARY KEY (id);


--
-- Name: tracker_device tracker_device_name_owner_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_device
    ADD CONSTRAINT tracker_device_name_owner_id_key UNIQUE (name, owner_id);


--
-- Name: tracker_device tracker_device_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_device
    ADD CONSTRAINT tracker_device_pkey PRIMARY KEY (imei);


--
-- Name: tracker_driver tracker_driver_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_driver
    ADD CONSTRAINT tracker_driver_pkey PRIMARY KEY (id);


--
-- Name: tracker_event tracker_event_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_event
    ADD CONSTRAINT tracker_event_pkey PRIMARY KEY (id);


--
-- Name: tracker_geofence tracker_geofence_name_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_geofence
    ADD CONSTRAINT tracker_geofence_name_key UNIQUE (name);


--
-- Name: tracker_geofence tracker_geofence_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_geofence
    ADD CONSTRAINT tracker_geofence_pkey PRIMARY KEY (id);


--
-- Name: tracker_gsmevent tracker_gsmevent_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_gsmevent
    ADD CONSTRAINT tracker_gsmevent_pkey PRIMARY KEY (event_ptr_id);


--
-- Name: tracker_ioevent tracker_ioevent_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ioevent
    ADD CONSTRAINT tracker_ioevent_pkey PRIMARY KEY (event_ptr_id);


--
-- Name: tracker_overlays tracker_overlays_name_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_overlays
    ADD CONSTRAINT tracker_overlays_name_key UNIQUE (name);


--
-- Name: tracker_overlays tracker_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_overlays
    ADD CONSTRAINT tracker_overlays_pkey PRIMARY KEY (id);


--
-- Name: tracker_psical tracker_psical_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_psical
    ADD CONSTRAINT tracker_psical_pkey PRIMARY KEY (id);


--
-- Name: tracker_psiweightlog tracker_psiweightlog_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_psiweightlog
    ADD CONSTRAINT tracker_psiweightlog_pkey PRIMARY KEY (id);


--
-- Name: tracker_resetevent tracker_resetevent_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_resetevent
    ADD CONSTRAINT tracker_resetevent_pkey PRIMARY KEY (event_ptr_id);


--
-- Name: tracker_serversms tracker_serversms_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_serversms
    ADD CONSTRAINT tracker_serversms_pkey PRIMARY KEY (id);


--
-- Name: tracker_sgavl tracker_sgavl_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgavl
    ADD CONSTRAINT tracker_sgavl_pkey PRIMARY KEY (device_ptr_id);


--
-- Name: tracker_sgavl tracker_sgavl_sim_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgavl
    ADD CONSTRAINT tracker_sgavl_sim_id_key UNIQUE (sim_id);


--
-- Name: tracker_sgharness tracker_sgharness_name_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgharness
    ADD CONSTRAINT tracker_sgharness_name_key UNIQUE (name);


--
-- Name: tracker_sgharness tracker_sgharness_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgharness
    ADD CONSTRAINT tracker_sgharness_pkey PRIMARY KEY (id);


--
-- Name: tracker_simcard tracker_simcard_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_simcard
    ADD CONSTRAINT tracker_simcard_pkey PRIMARY KEY (iccid);


--
-- Name: tracker_stats tracker_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_stats
    ADD CONSTRAINT tracker_stats_pkey PRIMARY KEY (id);


--
-- Name: tracker_ticketdetails tracker_ticketdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ticketdetails
    ADD CONSTRAINT tracker_ticketdetails_pkey PRIMARY KEY (id);


--
-- Name: tracker_ticketslog tracker_ticketslog_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ticketslog
    ADD CONSTRAINT tracker_ticketslog_pkey PRIMARY KEY (id);


--
-- Name: tracker_timesheetcapture tracker_timesheetcapture_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_timesheetcapture
    ADD CONSTRAINT tracker_timesheetcapture_pkey PRIMARY KEY (id);


--
-- Name: tracker_tracking_fences tracker_tracking_fences_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking_fences
    ADD CONSTRAINT tracker_tracking_fences_pkey PRIMARY KEY (id);


--
-- Name: tracker_tracking_fences tracker_tracking_fences_tracking_id_geofence_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking_fences
    ADD CONSTRAINT tracker_tracking_fences_tracking_id_geofence_id_key UNIQUE (tracking_id, geofence_id);


--
-- Name: tracker_tracking tracker_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking
    ADD CONSTRAINT tracker_tracking_pkey PRIMARY KEY (id);


--
-- Name: tracker_tracking tracker_tracking_tracking_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking
    ADD CONSTRAINT tracker_tracking_tracking_key UNIQUE (tracking);


--
-- Name: udp_udpsession udp_udpsession_imei_id_key; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.udp_udpsession
    ADD CONSTRAINT udp_udpsession_imei_id_key UNIQUE (imei_id);


--
-- Name: udp_udpsession udp_udpsession_pkey; Type: CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.udp_udpsession
    ADD CONSTRAINT udp_udpsession_pkey PRIMARY KEY (session);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_group_permissions_group_id ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_group_permissions_permission_id ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_message_user_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_message_user_id ON public.auth_message USING btree (user_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_permission_content_type_id ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_user_groups_group_id ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_user_groups_user_id ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_user_user_permissions_permission_id ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX auth_user_user_permissions_user_id ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX django_admin_log_content_type_id ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX django_admin_log_user_id ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX django_session_expire_date ON public.django_session USING btree (expire_date);


--
-- Name: gprs_packet_session_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX gprs_packet_session_id ON public.gprs_packet USING btree (session_id);


--
-- Name: gprs_record_packet_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX gprs_record_packet_id ON public.gprs_record USING btree (packet_id);


--
-- Name: gprs_session_dev_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX gprs_session_dev_id ON public.gprs_session USING btree (dev_id);


--
-- Name: gprs_session_dev_id_start_custom; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX gprs_session_dev_id_start_custom ON public.gprs_session USING btree (dev_id, start);


--
-- Name: gprs_session_start; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX gprs_session_start ON public.gprs_session USING btree (start);


--
-- Name: tracker_accellog_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_accellog_imei_id ON public.tracker_accellog USING btree (imei_id);


--
-- Name: tracker_accellog_imei_id_date_custom; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_accellog_imei_id_date_custom ON public.tracker_accellog USING btree (imei_id, date);


--
-- Name: tracker_accellog_position_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_accellog_position_id ON public.tracker_accellog USING gist ("position" public.gist_geometry_ops);


--
-- Name: tracker_addresscache_date_idx; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_addresscache_date_idx ON public.tracker_addresscache USING btree (date);


--
-- Name: tracker_addresscache_position_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_addresscache_position_id ON public.tracker_addresscache USING gist ("position" public.gist_geometry_ops);


--
-- Name: tracker_addresscache_text; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_addresscache_text ON public.tracker_addresscache USING btree (text);


--
-- Name: tracker_alarmlog_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_alarmlog_imei_id ON public.tracker_alarmlog USING btree (imei_id);


--
-- Name: tracker_alarmlog_sensor_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_alarmlog_sensor_date ON public.tracker_alarmlog USING btree (sensor, date);


--
-- Name: tracker_device_owner_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_device_owner_id ON public.tracker_device USING btree (owner_id);


--
-- Name: tracker_device_position_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_device_position_id ON public.tracker_device USING gist ("position" public.gist_geometry_ops);


--
-- Name: tracker_event_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_event_imei_id ON public.tracker_event USING btree (imei_id);


--
-- Name: tracker_event_imei_id_date_custom; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_event_imei_id_date_custom ON public.tracker_event USING btree (imei_id, date);


--
-- Name: tracker_event_imei_id_id_custom; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_event_imei_id_id_custom ON public.tracker_event USING btree (imei_id, id);


--
-- Name: tracker_geofence_fence_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_geofence_fence_id ON public.tracker_geofence USING gist (fence public.gist_geometry_ops);


--
-- Name: tracker_geofence_owner_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_geofence_owner_id ON public.tracker_geofence USING btree (owner_id);


--
-- Name: tracker_overlays_geometry_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_overlays_geometry_id ON public.tracker_overlays USING gist (geometry public.gist_geometry_ops);


--
-- Name: tracker_overlays_owner_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_overlays_owner_id ON public.tracker_overlays USING btree (owner_id);


--
-- Name: tracker_psical_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_psical_imei_id ON public.tracker_psical USING btree (imei_id);


--
-- Name: tracker_psiweightlog_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_psiweightlog_imei_id ON public.tracker_psiweightlog USING btree (imei_id);


--
-- Name: tracker_psiweightlog_imei_id_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_psiweightlog_imei_id_date ON public.tracker_psiweightlog USING btree (imei_id, date);


--
-- Name: tracker_psiweightlog_imei_id_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_psiweightlog_imei_id_id ON public.tracker_psiweightlog USING btree (imei_id, id);


--
-- Name: tracker_psiweightlog_sensor_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_psiweightlog_sensor_date ON public.tracker_psiweightlog USING btree (sensor, date);


--
-- Name: tracker_serversms_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_serversms_imei_id ON public.tracker_serversms USING btree (imei_id);


--
-- Name: tracker_sgavl_harness_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_sgavl_harness_id ON public.tracker_sgavl USING btree (harness_id);


--
-- Name: tracker_stats_date_start; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_stats_date_start ON public.tracker_stats USING btree (date_start);


--
-- Name: tracker_stats_name_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_stats_name_date ON public.tracker_stats USING btree (name, date_end);


--
-- Name: tracker_ticketdetails_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_ticketdetails_date ON public.tracker_ticketdetails USING btree (date);


--
-- Name: tracker_ticketdetails_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_ticketdetails_imei_id ON public.tracker_ticketdetails USING btree (imei_id);


--
-- Name: tracker_ticketslod_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_ticketslod_date ON public.tracker_ticketslog USING btree (date);


--
-- Name: tracker_timesheetcapture_date; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_timesheetcapture_date ON public.tracker_timesheetcapture USING btree (date);


--
-- Name: tracker_tracking_fences_geofence_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_tracking_fences_geofence_id ON public.tracker_tracking_fences USING btree (geofence_id);


--
-- Name: tracker_tracking_fences_tracking_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_tracking_fences_tracking_id ON public.tracker_tracking_fences USING btree (tracking_id);


--
-- Name: tracker_tracking_imei_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_tracking_imei_id ON public.tracker_tracking USING btree (imei_id);


--
-- Name: tracker_tracking_start; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_tracking_start ON public.tracker_tracking USING btree (start);


--
-- Name: tracker_tracking_stop; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX tracker_tracking_stop ON public.tracker_tracking USING btree (stop);


--
-- Name: tracker_tracking_stopFence_id; Type: INDEX; Schema: public; Owner: django13
--

CREATE INDEX "tracker_tracking_stopFence_id" ON public.tracker_tracking USING btree ("stopFence_id");


--
-- Name: auth_group_permissions auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_message auth_message_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_message
    ADD CONSTRAINT auth_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gprs_packet gprs_packet_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_packet
    ADD CONSTRAINT gprs_packet_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.gprs_session(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gprs_record gprs_record_packet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_record
    ADD CONSTRAINT gprs_record_packet_id_fkey FOREIGN KEY (packet_id) REFERENCES public.gprs_packet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gprs_session gprs_session_dev_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.gprs_session
    ADD CONSTRAINT gprs_session_dev_id_fkey FOREIGN KEY (dev_id) REFERENCES public.tracker_sgavl(device_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_sgavl harness_id_refs_id_f0e89614; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgavl
    ADD CONSTRAINT harness_id_refs_id_f0e89614 FOREIGN KEY (harness_id) REFERENCES public.tracker_sgharness(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_accellog tracker_accellog_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_accellog
    ADD CONSTRAINT tracker_accellog_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_alarmlog tracker_alarmlog_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_alarmlog
    ADD CONSTRAINT tracker_alarmlog_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_device tracker_device_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_device
    ADD CONSTRAINT tracker_device_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_event tracker_event_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_event
    ADD CONSTRAINT tracker_event_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_geofence tracker_geofence_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_geofence
    ADD CONSTRAINT tracker_geofence_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_gsmevent tracker_gsmevent_event_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_gsmevent
    ADD CONSTRAINT tracker_gsmevent_event_ptr_id_fkey FOREIGN KEY (event_ptr_id) REFERENCES public.tracker_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_ioevent tracker_ioevent_event_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ioevent
    ADD CONSTRAINT tracker_ioevent_event_ptr_id_fkey FOREIGN KEY (event_ptr_id) REFERENCES public.tracker_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_overlays tracker_overlays_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_overlays
    ADD CONSTRAINT tracker_overlays_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_psical tracker_psical_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_psical
    ADD CONSTRAINT tracker_psical_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_psiweightlog tracker_psiweightlog_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_psiweightlog
    ADD CONSTRAINT tracker_psiweightlog_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_resetevent tracker_resetevent_event_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_resetevent
    ADD CONSTRAINT tracker_resetevent_event_ptr_id_fkey FOREIGN KEY (event_ptr_id) REFERENCES public.tracker_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_serversms tracker_serversms_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_serversms
    ADD CONSTRAINT tracker_serversms_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_sgavl(device_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_sgavl tracker_sgavl_device_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgavl
    ADD CONSTRAINT tracker_sgavl_device_ptr_id_fkey FOREIGN KEY (device_ptr_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_sgavl tracker_sgavl_sim_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_sgavl
    ADD CONSTRAINT tracker_sgavl_sim_id_fkey FOREIGN KEY (sim_id) REFERENCES public.tracker_simcard(iccid) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_ticketdetails tracker_ticketdetails_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_ticketdetails
    ADD CONSTRAINT tracker_ticketdetails_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_tracking_fences tracker_tracking_fences_geofence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking_fences
    ADD CONSTRAINT tracker_tracking_fences_geofence_id_fkey FOREIGN KEY (geofence_id) REFERENCES public.tracker_geofence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_tracking tracker_tracking_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking
    ADD CONSTRAINT tracker_tracking_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_tracking tracker_tracking_stopFence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking
    ADD CONSTRAINT "tracker_tracking_stopFence_id_fkey" FOREIGN KEY ("stopFence_id") REFERENCES public.tracker_geofence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tracker_tracking_fences tracking_id_refs_id_9b3c8dd9; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.tracker_tracking_fences
    ADD CONSTRAINT tracking_id_refs_id_9b3c8dd9 FOREIGN KEY (tracking_id) REFERENCES public.tracker_tracking(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: udp_udpsession udp_udpsession_imei_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.udp_udpsession
    ADD CONSTRAINT udp_udpsession_imei_id_fkey FOREIGN KEY (imei_id) REFERENCES public.tracker_device(imei) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups user_id_refs_id_831107f1; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT user_id_refs_id_831107f1 FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions user_id_refs_id_f2045483; Type: FK CONSTRAINT; Schema: public; Owner: django13
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_f2045483 FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: DATABASE skyguard; Type: ACL; Schema: -; Owner: django13
--

GRANT CONNECT ON DATABASE skyguard TO link_eisa;
GRANT CONNECT ON DATABASE skyguard TO eisa;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA public TO link_eisa;
GRANT USAGE ON SCHEMA public TO eisa;


--
-- Name: TABLE auth_group; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_group TO eisa;


--
-- Name: TABLE auth_group_permissions; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_group_permissions TO eisa;


--
-- Name: TABLE auth_message; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_message TO eisa;


--
-- Name: TABLE auth_permission; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_permission TO eisa;


--
-- Name: TABLE auth_user; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_user TO eisa;


--
-- Name: TABLE auth_user_groups; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_user_groups TO eisa;


--
-- Name: TABLE auth_user_user_permissions; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.auth_user_user_permissions TO eisa;


--
-- Name: TABLE django_admin_log; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.django_admin_log TO eisa;


--
-- Name: TABLE django_content_type; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.django_content_type TO eisa;


--
-- Name: TABLE django_session; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.django_session TO eisa;


--
-- Name: TABLE django_site; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.django_site TO eisa;


--
-- Name: TABLE gprs_packet; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.gprs_packet TO eisa;


--
-- Name: TABLE gprs_record; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.gprs_record TO eisa;


--
-- Name: TABLE gprs_session; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.gprs_session TO eisa;


--
-- Name: TABLE tracker_accellog; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_accellog TO eisa;


--
-- Name: TABLE tracker_addresscache; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_addresscache TO eisa;


--
-- Name: TABLE tracker_alarmlog; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_alarmlog TO eisa;


--
-- Name: TABLE tracker_device; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_device TO eisa;


--
-- Name: TABLE tracker_driver; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_driver TO eisa;


--
-- Name: TABLE tracker_event; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_event TO eisa;


--
-- Name: TABLE tracker_geofence; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_geofence TO eisa;


--
-- Name: TABLE tracker_gsmevent; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_gsmevent TO eisa;


--
-- Name: TABLE tracker_ioevent; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_ioevent TO eisa;


--
-- Name: TABLE tracker_overlays; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_overlays TO eisa;


--
-- Name: TABLE tracker_psical; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_psical TO eisa;


--
-- Name: TABLE tracker_psiweightlog; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_psiweightlog TO eisa;


--
-- Name: TABLE tracker_resetevent; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_resetevent TO eisa;


--
-- Name: TABLE tracker_serversms; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_serversms TO eisa;


--
-- Name: TABLE tracker_sgavl; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_sgavl TO eisa;


--
-- Name: TABLE tracker_sgharness; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_sgharness TO eisa;


--
-- Name: TABLE tracker_simcard; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_simcard TO eisa;


--
-- Name: TABLE tracker_stats; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_stats TO link_eisa;
GRANT SELECT ON TABLE public.tracker_stats TO eisa;


--
-- Name: TABLE tracker_ticketdetails; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_ticketdetails TO eisa;


--
-- Name: TABLE tracker_ticketslog; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_ticketslog TO eisa;


--
-- Name: TABLE tracker_timesheetcapture; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_timesheetcapture TO link_eisa;
GRANT SELECT ON TABLE public.tracker_timesheetcapture TO eisa;


--
-- Name: TABLE tracker_tracking; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_tracking TO eisa;


--
-- Name: TABLE tracker_tracking_fences; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.tracker_tracking_fences TO eisa;


--
-- Name: TABLE udp_udpsession; Type: ACL; Schema: public; Owner: django13
--

GRANT SELECT ON TABLE public.udp_udpsession TO eisa;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES  TO eisa;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES  TO link_eisa;


--
-- PostgreSQL database dump complete
--

